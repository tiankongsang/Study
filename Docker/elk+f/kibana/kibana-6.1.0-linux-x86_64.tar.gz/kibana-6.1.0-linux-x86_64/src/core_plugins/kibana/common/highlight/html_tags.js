'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
// These are the html tags that will replace the highlight tags.
const htmlTags = exports.htmlTags = {
  pre: '<mark>',
  post: '</mark>'
};
