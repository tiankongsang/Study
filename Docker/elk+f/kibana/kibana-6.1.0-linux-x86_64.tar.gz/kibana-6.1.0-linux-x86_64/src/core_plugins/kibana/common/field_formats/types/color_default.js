'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
const DEFAULT_COLOR = exports.DEFAULT_COLOR = {
  range: `${Number.NEGATIVE_INFINITY}:${Number.POSITIVE_INFINITY}`,
  regex: '<insert regex>',
  text: '#000000',
  background: '#ffffff'
};
